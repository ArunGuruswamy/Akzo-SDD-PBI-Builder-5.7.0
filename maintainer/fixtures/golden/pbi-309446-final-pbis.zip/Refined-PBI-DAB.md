# Measurement validation — Refined PBI: DAB backend

Status: Development-Ready

- PBI number: 309446. Local draft identifier: pbi-309446-measurement-validation-20261107232431664-b0156f0a-DAB (no Azure DevOps work item was created).
- Shared requirement: PBI 309446, playbook/pbis/pbi-309446-measurement-validation-20261107232431664-b0156f0a/REQUEST.md
- Development target: DAB + UI
- Related PBIs: Refined-PBI-UI.md
- Generated from pbi-state.json by Akzo SDD PBI Builder 5.7.0.

## Description

Validate measurements before saving

## Original acceptance criteria (as submitted)

1. Given an invalid value, when it is saved, then the save is rejected with a clear message.

## Business requirements

### BR-1 (rev 1)

A measurement with an invalid value is rejected with a clear message

- Context: Measurement, create, all business units
- Enforced today by: application (CreateMeasurementHandler)
- Development action: implement
- Path cdms: not-applicable — CDMS is a reference for this target
- Path dab: bypasses (EV-6)
- Path ui: reaches (EV-7)
- Decision: DEC-1

## Acceptance criteria

- AC-1 (positive; BR-1): Given a valid measurement, when it is saved, then it is stored
- AC-2 (negative; BR-1): Given an invalid value, when it is saved, then the save is rejected with a clear message

## Technical implementation approach

- BR-1: implement in DAB (GraphQL).
  - Branch BR-1.Y: when The value is valid, The measurement is saved.
    - Coverage: DAB: covered, UI: covered
    - Evidence: EV-2 [code] CDMS Repo/Handlers/CreateMeasurementHandler.cs — Handle: CDMS handler validates and saves
    - Evidence: EV-3 [code] DAB Repo/Handlers/CreateMeasurementHandler.cs — Handle: DAB handler validates with FluentValidation and saves
    - Evidence: EV-4 [code] UI Repo/src/app/measurement/measurement.component.ts — save: Shared UI component saves through the service
    - Acceptance criteria: AC-1
  - Branch BR-1.N: when The value is invalid, The save is rejected with a clear message.
    - Coverage: DAB: partial, UI: covered
    - Evidence: EV-2 [code] CDMS Repo/Handlers/CreateMeasurementHandler.cs — Handle: CDMS handler validates and saves
    - Evidence: EV-4 [code] UI Repo/src/app/measurement/measurement.component.ts — save: Shared UI component saves through the service
    - Acceptance criteria: AC-2
- CDMS was analyzed as a read-only implementation reference; see the code references.

## Existing code references

- EV-1 [code] Legacy Repo/Plugins/MeasurementCreatePlugin.cs — Execute: Legacy plugin rejects an invalid measurement
- EV-2 [code] CDMS Repo/Handlers/CreateMeasurementHandler.cs — Handle: CDMS handler validates and saves
- EV-3 [code] DAB Repo/Handlers/CreateMeasurementHandler.cs — Handle: DAB handler validates with FluentValidation and saves
- EV-4 [code] UI Repo/src/app/measurement/measurement.component.ts — save: Shared UI component saves through the service
- EV-6 [reach] DAB Repo/Program.cs — host: DAB host registers the handlers
- EV-7 [reach] UI Repo/src/app/measurement/measurement.service.ts — create: Shared UI posts to the configured API URL

## Dependencies

None.

## Validation requirements

- BR-1: positive, negative scenarios; enforced by application.

## Test scenarios

- Verify AC-1 (positive)
- Verify AC-2 (negative)

## Business decisions

- DEC-1:  (Stated in the original request (Description))
- DEC-2: Reject it with a clear message (Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.688Z (option A))
- DEC-3: All business units (Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.704Z (option A))
- DEC-4: Yes, show it (Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.717Z (option A))
- DEC-5: Yes (Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.730Z (option A))
- DEC-6: Yes (Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.743Z (option A))
- DEC-7: Yes (Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.757Z (option A))

## Risks, open issues and assumptions

- BR-1: The audit-trail side effect of the legacy plugin is not verified (informational evidence gap; does not block the PBI)

## Related requirements owned by other PBIs

- BR-2: The saved measurement shows which instrument measured it
- AC-3 (positive; BR-2): Given a saved measurement, when it is shown, then the instrument is displayed
- AC-4 (negative; BR-2): Given a measurement without an instrument, when it is shown, then a placeholder is displayed

## Approval

- Final user approval: Product owner, 2026-11-07T23:24:32.062Z (Approve & Generate in the PBI Builder wizard)
- PO/BA approval: not recorded by this tool; obtain it as your organization requires
- Technical approval: not recorded by this tool; obtain it as your organization requires
