# Measurement rules
A measurement value must be positive.
