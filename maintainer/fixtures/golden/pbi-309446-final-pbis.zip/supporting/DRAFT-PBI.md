# pbi-309446-measurement-validation-20261107232431664-b0156f0a
Status: Development-Ready

## Business rules and exceptions

- id: BR-1 | rule: A measurement with an invalid value is rejected with a clear message | context: Measurement, create, all business units | owner: {"component":"CreateMeasurementHandler","type":"application"} | decisionRef: DEC-1 | gaps: [{"description":"The audit-trail side effect of the legacy plugin is not verified","id":"GAP-1","impact":"INFORMATIONAL","status":"open"}]
- id: BR-2 | rule: The saved measurement shows which instrument measured it | context: Measurement, display | owner: {"component":"MeasurementComponent","type":"application"} | decisionRef: DEC-1

## Acceptance criteria

- id: AC-1 | rules: ["BR-1"] | type: positive | criterion: Given a valid measurement, when it is saved, then it is stored
- id: AC-2 | rules: ["BR-1"] | type: negative | criterion: Given an invalid value, when it is saved, then the save is rejected with a clear message
- id: AC-3 | rules: ["BR-2"] | type: positive | criterion: Given a saved measurement, when it is shown, then the instrument is displayed
- id: AC-4 | rules: ["BR-2"] | type: negative | criterion: Given a measurement without an instrument, when it is shown, then a placeholder is displayed

## Dependencies and cross-repository responsibilities

None recorded.

## Readiness

Canonical status: Ready for Review. See READINESS.json for the current checker result; prior narrative check counts are historical.

Approvals: {"poba":{"status":"pending"},"technical":{"status":"pending"},"user":{"status":"pending"}}

Conditional drafting does not approve implementation or close security blockers.

## Verified implementation and proposed work

None recorded.
