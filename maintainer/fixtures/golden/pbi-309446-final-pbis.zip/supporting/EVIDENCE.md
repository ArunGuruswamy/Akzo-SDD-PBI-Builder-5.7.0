# EVIDENCE

## Canonical evidence records

- id: EV-1 | level: code | kind: repo-file | system: legacy-crm | source: Legacy Repo/Plugins/MeasurementCreatePlugin.cs | location: Execute | sha256: c5f86b3f6a8362274f8157f9d6a86431331e8e7d07d7304c0d7f66defda0f89c | summary: Legacy plugin rejects an invalid measurement
- id: EV-2 | level: code | kind: repo-file | system: cdms | source: CDMS Repo/Handlers/CreateMeasurementHandler.cs | location: Handle | sha256: c31ac13835df6693556b068a5ce81801ccd91b767847cb47c6c051c14a6f7729 | summary: CDMS handler validates and saves
- id: EV-3 | level: code | kind: repo-file | system: dab | source: DAB Repo/Handlers/CreateMeasurementHandler.cs | location: Handle | sha256: 8d9ce0a87ecfadb7dee6ac1e7f529b26da0ece60f724b400a8f6b6464f40ed34 | summary: DAB handler validates with FluentValidation and saves
- id: EV-4 | level: code | kind: repo-file | system: ui | source: UI Repo/src/app/measurement/measurement.component.ts | location: save | sha256: b8b7b627c6a3e8889963a2cb8dd8180ba442cdd97d6324bd35ec198971979165 | summary: Shared UI component saves through the service
- id: EV-5 | level: reach | kind: repo-file | system: cdms | source: CDMS Repo/Functions/MeasurementFunctions.cs | location: HTTP trigger | sha256: 26ee1af74cd315e439633ef8607140696a13d1fbac012ff2300b5f50fef98c49 | summary: CDMS function reaches the handler
- id: EV-6 | level: reach | kind: repo-file | system: dab | source: DAB Repo/Program.cs | location: host | sha256: 3d7b2e150e95b7fa6f7e6fc0ff5a9d56709abfabefde9a2dd8eba8f54d9ce16a | summary: DAB host registers the handlers
- id: EV-7 | level: reach | kind: repo-file | system: ui | source: UI Repo/src/app/measurement/measurement.service.ts | location: create | sha256: 19a3f0a90efe2a414bd9423942c3b34ee0f1fd960a62e6f35a4f96c5d820d638 | summary: Shared UI posts to the configured API URL
