# VALIDATION-MATRIX

## Canonical acceptance coverage

- id: AC-1 | rules: ["BR-1"] | type: positive | criterion: Given a valid measurement, when it is saved, then it is stored
- id: AC-2 | rules: ["BR-1"] | type: negative | criterion: Given an invalid value, when it is saved, then the save is rejected with a clear message
- id: AC-3 | rules: ["BR-2"] | type: positive | criterion: Given a saved measurement, when it is shown, then the instrument is displayed
- id: AC-4 | rules: ["BR-2"] | type: negative | criterion: Given a measurement without an instrument, when it is shown, then a placeholder is displayed

## Canonical implementation verification

None recorded.
