# Original PBI request

## Title

Measurement validation

## PBI number

309446

## Target project

Workspace

## Development target

DAB + UI

## Repositories

- Custom (Legacy CRM/XRM) — Business reference: Custom (Legacy CRM/XRM) (Legacy Repo)
- CDMS — Implementation reference (read-only): CDMS Repo
- DAB (GraphQL) — Implementation target: DAB Repo
- Shared Angular UI — Shared frontend (implementation target): UI Repo

## Analysis plan

1. Custom (Legacy CRM/XRM): Trace the existing behavior (controllers, plugins, workflows, JavaScript, persistence); identify what the modern application already handles and what is missing.
2. Shared Angular UI (once): Build one reusable UI execution-flow map (components, services, calls, request and response shapes). Do not scan it again per backend.
3. CDMS: Read-only reference: inspect only API URLs, configuration, request and response contracts, authorization, behavior differences for the UI flow, then the backend implementation of each rule.
4. DAB (GraphQL): Implementation: inspect only API URLs, configuration, request and response contracts, authorization, behavior differences for the UI flow, then the backend implementation of each rule.

Each scan is done once; its result is reused by every later step.

## Analysis mode

Deep

## Additional implementation references (read-only)

None selected

## Kind of change

Not sure

## Description

Validate measurements before saving

## Acceptance criteria

1. Given an invalid value, when it is saved, then the save is rejected with a clear message.

## Attachments (not yet reviewed)

None

## Investigation scope

Not limited

## Additional notes

None

## Business reason

Not known yet

## Business example

Not known yet

## Business Unit / Sub-BU

Not known yet

Status: Intake — AI refinement not started. No approvals recorded.
