# Decision log

DEC-1 approved: stated in the original request.
- DEC-2 (approved): Q-1 Should an invalid value be rejected or corrected automatically? → Reject it with a clear message. Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.688Z (option A).
- DEC-3 (approved): Q-2 Which business units does the rule apply to? → All business units. Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.704Z (option A).
- DEC-4 (approved): Q-3 Is the instrument shown for historical measurements too? → Yes, show it. Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.717Z (option A).
- DEC-5 (approved): Q-4 Must a supervisor approve a corrected measurement? → Yes. Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.730Z (option A).
- DEC-6 (approved): Q-5 Is the reason for a rejection shown to the user? → Yes. Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.743Z (option A).
- DEC-7 (approved): Q-6 Are historical measurements migrated? → Yes. Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.757Z (option A).

## Canonical decision records

- id: DEC-1 | status: approved | evidence: Stated in the original request (Description) | supersedes: 
- id: DEC-2 | status: approved | decision: Reject it with a clear message | evidence: Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.688Z (option A) | supersedes: 
- id: DEC-3 | status: approved | decision: All business units | evidence: Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.704Z (option A) | supersedes: 
- id: DEC-4 | status: approved | decision: Yes, show it | evidence: Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.717Z (option A) | supersedes: 
- id: DEC-5 | status: approved | decision: Yes | evidence: Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.730Z (option A) | supersedes: 
- id: DEC-6 | status: approved | decision: Yes | evidence: Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.743Z (option A) | supersedes: 
- id: DEC-7 | status: approved | decision: Yes | evidence: Selected by Business analyst in the PBI Builder question panel at 2026-11-07T23:24:31.757Z (option A) | supersedes: 
