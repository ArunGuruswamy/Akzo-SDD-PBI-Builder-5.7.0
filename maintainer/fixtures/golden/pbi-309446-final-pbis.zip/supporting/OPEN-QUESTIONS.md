# OPEN-QUESTIONS

## Canonical questions and blockers

- id: Q-1 | question: Should an invalid value be rejected or corrected automatically? | status: answered | owner: po-ba | resolution: Reject it with a clear message | decisionRef: DEC-2
- id: Q-2 | question: Which business units does the rule apply to? | status: answered | owner: po-ba | resolution: All business units | decisionRef: DEC-3
- id: Q-3 | question: Is the instrument shown for historical measurements too? | status: answered | owner: po-ba | resolution: Yes, show it | decisionRef: DEC-4
- id: Q-4 | question: Must a supervisor approve a corrected measurement? | status: answered | owner: po-ba | resolution: Yes | decisionRef: DEC-5
- id: Q-5 | question: Is the reason for a rejection shown to the user? | status: answered | owner: po-ba | resolution: Yes | decisionRef: DEC-6
- id: Q-6 | question: Are historical measurements migrated? | status: answered | owner: po-ba | resolution: Yes | decisionRef: DEC-7

## Canonical external verification tasks

None recorded.
