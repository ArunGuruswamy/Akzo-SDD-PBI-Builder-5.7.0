# Branch coverage matrix

Generated from pbi-state.json (readiness: Development-Ready). Do not edit; change pbi-state.json and export again.

| Rule | Branch | Kind | Condition | Expected behavior | DAB coverage | UI coverage | Evidence | Risk | Proposed approach | Acceptance criteria |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| BR-1 | BR-1.Y | approved-requirement | The value is valid | The measurement is saved | covered | covered | EV-2 CDMS Repo/Handlers/CreateMeasurementHandler.cs Handle; EV-3 DAB Repo/Handlers/CreateMeasurementHandler.cs Handle; EV-4 UI Repo/src/app/measurement/measurement.component.ts save |  |  | AC-1 |
| BR-1 | BR-1.N | approved-requirement | The value is invalid | The save is rejected with a clear message | partial | covered | EV-2 CDMS Repo/Handlers/CreateMeasurementHandler.cs Handle; EV-4 UI Repo/src/app/measurement/measurement.component.ts save |  |  | AC-2 |

## Open gaps
- BR-1 / BR-1.N / DAB / partial: The save is rejected with a clear message (approved-requirement)
- BR-1 / evidence-gap: The audit-trail side effect of the legacy plugin is not verified (technical-finding)
